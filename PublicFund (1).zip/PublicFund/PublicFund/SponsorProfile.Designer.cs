﻿namespace PublicFund
{
    partial class SponsorProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SponsorProfile));
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSName = new System.Windows.Forms.Label();
            this.txtSGender = new System.Windows.Forms.Label();
            this.txtSBOD = new System.Windows.Forms.Label();
            this.txtSPhone1 = new System.Windows.Forms.Label();
            this.txtSEmail = new System.Windows.Forms.Label();
            this.txtSNID = new System.Windows.Forms.Label();
            this.txtSOccupation = new System.Windows.Forms.Label();
            this.txtSBG = new System.Windows.Forms.Label();
            this.txtSArea = new System.Windows.Forms.Label();
            this.txtSCity = new System.Windows.Forms.Label();
            this.txtSCountry = new System.Windows.Forms.Label();
            this.txtSPhone2 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtSUserName = new System.Windows.Forms.Label();
            this.UserName = new System.Windows.Forms.Label();
            this.txtSID = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(611, 295);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 23);
            this.label14.TabIndex = 103;
            this.label14.Text = "Occupation:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(486, 21);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(181, 41);
            this.label10.TabIndex = 102;
            this.label10.Text = "My Profile";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(669, 420);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 23);
            this.label11.TabIndex = 96;
            this.label11.Text = "City:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(663, 379);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 23);
            this.label12.TabIndex = 94;
            this.label12.Text = "Area:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(601, 337);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(124, 23);
            this.label13.TabIndex = 93;
            this.label13.Text = "Blood Group:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(636, 461);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 23);
            this.label8.TabIndex = 91;
            this.label8.Text = "Country:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(134, 151);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 26);
            this.label7.TabIndex = 90;
            this.label7.Text = "ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(588, 253);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 23);
            this.label4.TabIndex = 89;
            this.label4.Text = "Date Of Birth:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(132, 454);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 23);
            this.label5.TabIndex = 87;
            this.label5.Text = "NID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(119, 413);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 23);
            this.label6.TabIndex = 85;
            this.label6.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(101, 325);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 23);
            this.label3.TabIndex = 83;
            this.label3.Text = "Phone 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(106, 274);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 23);
            this.label2.TabIndex = 82;
            this.label2.Text = "Gender:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(119, 229);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 23);
            this.label1.TabIndex = 80;
            this.label1.Text = "Name:";
            // 
            // txtSName
            // 
            this.txtSName.AutoSize = true;
            this.txtSName.BackColor = System.Drawing.Color.Transparent;
            this.txtSName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSName.Location = new System.Drawing.Point(194, 229);
            this.txtSName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSName.Name = "txtSName";
            this.txtSName.Size = new System.Drawing.Size(96, 26);
            this.txtSName.TabIndex = 104;
            this.txtSName.Text = "*******";
            // 
            // txtSGender
            // 
            this.txtSGender.AutoSize = true;
            this.txtSGender.BackColor = System.Drawing.Color.Transparent;
            this.txtSGender.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSGender.Location = new System.Drawing.Point(195, 274);
            this.txtSGender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSGender.Name = "txtSGender";
            this.txtSGender.Size = new System.Drawing.Size(96, 26);
            this.txtSGender.TabIndex = 105;
            this.txtSGender.Text = "*******";
            // 
            // txtSBOD
            // 
            this.txtSBOD.AutoSize = true;
            this.txtSBOD.BackColor = System.Drawing.Color.Transparent;
            this.txtSBOD.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSBOD.Location = new System.Drawing.Point(729, 253);
            this.txtSBOD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSBOD.Name = "txtSBOD";
            this.txtSBOD.Size = new System.Drawing.Size(96, 26);
            this.txtSBOD.TabIndex = 106;
            this.txtSBOD.Text = "*******";
            // 
            // txtSPhone1
            // 
            this.txtSPhone1.AutoSize = true;
            this.txtSPhone1.BackColor = System.Drawing.Color.Transparent;
            this.txtSPhone1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPhone1.Location = new System.Drawing.Point(194, 325);
            this.txtSPhone1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSPhone1.Name = "txtSPhone1";
            this.txtSPhone1.Size = new System.Drawing.Size(96, 26);
            this.txtSPhone1.TabIndex = 107;
            this.txtSPhone1.Text = "*******";
            // 
            // txtSEmail
            // 
            this.txtSEmail.AutoSize = true;
            this.txtSEmail.BackColor = System.Drawing.Color.Transparent;
            this.txtSEmail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSEmail.Location = new System.Drawing.Point(194, 413);
            this.txtSEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSEmail.Name = "txtSEmail";
            this.txtSEmail.Size = new System.Drawing.Size(96, 26);
            this.txtSEmail.TabIndex = 108;
            this.txtSEmail.Text = "*******";
            // 
            // txtSNID
            // 
            this.txtSNID.AutoSize = true;
            this.txtSNID.BackColor = System.Drawing.Color.Transparent;
            this.txtSNID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSNID.Location = new System.Drawing.Point(194, 454);
            this.txtSNID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSNID.Name = "txtSNID";
            this.txtSNID.Size = new System.Drawing.Size(96, 26);
            this.txtSNID.TabIndex = 109;
            this.txtSNID.Text = "*******";
            // 
            // txtSOccupation
            // 
            this.txtSOccupation.AutoSize = true;
            this.txtSOccupation.BackColor = System.Drawing.Color.Transparent;
            this.txtSOccupation.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSOccupation.Location = new System.Drawing.Point(729, 295);
            this.txtSOccupation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSOccupation.Name = "txtSOccupation";
            this.txtSOccupation.Size = new System.Drawing.Size(96, 26);
            this.txtSOccupation.TabIndex = 110;
            this.txtSOccupation.Text = "*******";
            // 
            // txtSBG
            // 
            this.txtSBG.AutoSize = true;
            this.txtSBG.BackColor = System.Drawing.Color.Transparent;
            this.txtSBG.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSBG.Location = new System.Drawing.Point(729, 337);
            this.txtSBG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSBG.Name = "txtSBG";
            this.txtSBG.Size = new System.Drawing.Size(96, 26);
            this.txtSBG.TabIndex = 111;
            this.txtSBG.Text = "*******";
            // 
            // txtSArea
            // 
            this.txtSArea.AutoSize = true;
            this.txtSArea.BackColor = System.Drawing.Color.Transparent;
            this.txtSArea.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSArea.Location = new System.Drawing.Point(729, 379);
            this.txtSArea.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSArea.Name = "txtSArea";
            this.txtSArea.Size = new System.Drawing.Size(96, 26);
            this.txtSArea.TabIndex = 112;
            this.txtSArea.Text = "*******";
            // 
            // txtSCity
            // 
            this.txtSCity.AutoSize = true;
            this.txtSCity.BackColor = System.Drawing.Color.Transparent;
            this.txtSCity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSCity.Location = new System.Drawing.Point(729, 421);
            this.txtSCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSCity.Name = "txtSCity";
            this.txtSCity.Size = new System.Drawing.Size(96, 26);
            this.txtSCity.TabIndex = 113;
            this.txtSCity.Text = "*******";
            // 
            // txtSCountry
            // 
            this.txtSCountry.AutoSize = true;
            this.txtSCountry.BackColor = System.Drawing.Color.Transparent;
            this.txtSCountry.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSCountry.Location = new System.Drawing.Point(729, 461);
            this.txtSCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSCountry.Name = "txtSCountry";
            this.txtSCountry.Size = new System.Drawing.Size(96, 26);
            this.txtSCountry.TabIndex = 114;
            this.txtSCountry.Text = "*******";
            // 
            // txtSPhone2
            // 
            this.txtSPhone2.AutoSize = true;
            this.txtSPhone2.BackColor = System.Drawing.Color.Transparent;
            this.txtSPhone2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPhone2.Location = new System.Drawing.Point(194, 371);
            this.txtSPhone2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSPhone2.Name = "txtSPhone2";
            this.txtSPhone2.Size = new System.Drawing.Size(96, 26);
            this.txtSPhone2.TabIndex = 117;
            this.txtSPhone2.Text = "*******";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(100, 371);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 23);
            this.label15.TabIndex = 116;
            this.label15.Text = "Phone 2:";
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Cooper Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(1059, 612);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(100, 42);
            this.btnClose.TabIndex = 146;
            this.btnClose.Text = "Close";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtSUserName
            // 
            this.txtSUserName.AutoSize = true;
            this.txtSUserName.BackColor = System.Drawing.Color.Transparent;
            this.txtSUserName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSUserName.Location = new System.Drawing.Point(194, 190);
            this.txtSUserName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSUserName.Name = "txtSUserName";
            this.txtSUserName.Size = new System.Drawing.Size(96, 26);
            this.txtSUserName.TabIndex = 151;
            this.txtSUserName.Text = "*******";
            // 
            // UserName
            // 
            this.UserName.AutoSize = true;
            this.UserName.BackColor = System.Drawing.Color.Transparent;
            this.UserName.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserName.Location = new System.Drawing.Point(76, 190);
            this.UserName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(111, 23);
            this.UserName.TabIndex = 150;
            this.UserName.Text = "User Name:";
            // 
            // txtSID
            // 
            this.txtSID.AutoSize = true;
            this.txtSID.BackColor = System.Drawing.Color.Transparent;
            this.txtSID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSID.Location = new System.Drawing.Point(198, 150);
            this.txtSID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.txtSID.Name = "txtSID";
            this.txtSID.Size = new System.Drawing.Size(96, 26);
            this.txtSID.TabIndex = 152;
            this.txtSID.Text = "*******";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(673, 91);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 142);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 194;
            this.pictureBox1.TabStop = false;
            // 
            // SponsorProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtSID);
            this.Controls.Add(this.txtSUserName);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtSPhone2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtSCountry);
            this.Controls.Add(this.txtSCity);
            this.Controls.Add(this.txtSArea);
            this.Controls.Add(this.txtSBG);
            this.Controls.Add(this.txtSOccupation);
            this.Controls.Add(this.txtSNID);
            this.Controls.Add(this.txtSEmail);
            this.Controls.Add(this.txtSPhone1);
            this.Controls.Add(this.txtSBOD);
            this.Controls.Add(this.txtSGender);
            this.Controls.Add(this.txtSName);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SponsorProfile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sponsor Profile";
            this.Load += new System.EventHandler(this.SponsorProfile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txtSName;
        private System.Windows.Forms.Label txtSGender;
        private System.Windows.Forms.Label txtSBOD;
        private System.Windows.Forms.Label txtSPhone1;
        private System.Windows.Forms.Label txtSEmail;
        private System.Windows.Forms.Label txtSNID;
        private System.Windows.Forms.Label txtSOccupation;
        private System.Windows.Forms.Label txtSBG;
        private System.Windows.Forms.Label txtSArea;
        private System.Windows.Forms.Label txtSCity;
        private System.Windows.Forms.Label txtSCountry;
        private System.Windows.Forms.Label txtSPhone2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label txtSUserName;
        private System.Windows.Forms.Label UserName;
        private System.Windows.Forms.Label txtSID;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}